import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;

public class weatherForecastApp {
    private static final String API_KEY = "YOUR_API_KEY"; // Replace with your own API key

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter city name:");
        String city = scanner.nextLine();

        try {
            String weatherData = getWeatherData(city);
            System.out.println(weatherData);
        } catch (IOException e) {
            System.out.println("Error occurred while retrieving weather data: " + e.getMessage());
        }

        scanner.close();
    }

    private static String getWeatherData(String city) throws IOException {
        String urlString = "http://api.openweathermap.org/data/2.5/weather?q=" + city + "&appid=" + API_KEY;

        URL url = new URL(urlString);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        if (responseCode == HttpURLConnection.HTTP_OK) {
            BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            String line;
            StringBuilder response = new StringBuilder();

            while ((line = reader.readLine()) != null) {
                response.append(line);
            }

            reader.close();
            return response.toString();
        } else {
            throw new IOException("HTTP error code: " + responseCode);
        }
    }
}
