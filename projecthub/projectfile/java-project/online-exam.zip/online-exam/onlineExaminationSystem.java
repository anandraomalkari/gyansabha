import java.util.Scanner;

public class onlineExaminationSystem {
    private static String[] questions = {
        "1. What is the capital of France?",
        "2. Who painted the Mona Lisa?",
        "3. What is the largest planet in our solar system?",
        "4. What is the chemical symbol for gold?",
        "5. Who is the author of 'To Kill a Mockingbird'?"
    };
    
    private static String[] options = {
        "a. London\tb. Paris\tc. Rome\td. Berlin",
        "a. Leonardo da Vinci\tb. Vincent van Gogh\tc. Pablo Picasso\td. Michelangelo",
        "a. Mars\tb. Jupiter\tc. Earth\td. Saturn",
        "a. Au\tb. Go\tc. Gu\td. Gr",
        "a. Harper Lee\tb. Mark Twain\tc. J.D. Salinger\td. F. Scott Fitzgerald"
    };
    
    private static char[] correctAnswers = {
        'b', 'a', 'b', 'a', 'a'
    };
    
    private static int totalQuestions = questions.length;
    
    private static int score = 0;
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.println("*** Online Examination System ***");
        System.out.print("Enter your name: ");
        String name = scanner.nextLine();
        
        System.out.println("\nHello " + name + "! Welcome to the online examination.\n");
        System.out.println("Please select the correct option for each question.\n");
        
        for (int i = 0; i < totalQuestions; i++) {
            System.out.println(questions[i]);
            System.out.println(options[i]);
            
            System.out.print("Your answer (a, b, c, or d): ");
            char answer = Character.toLowerCase(scanner.nextLine().charAt(0));
            
            if (answer == correctAnswers[i]) {
                score++;
                System.out.println("Correct!\n");
            } else {
                System.out.println("Incorrect!\n");
            }
        }
        
        System.out.println("**** Results ****");
        System.out.println("Name: " + name);
        System.out.println("Total Questions: " + totalQuestions);
        System.out.println("Correct Answers: " + score);
        System.out.println("Incorrect Answers: " + (totalQuestions - score));
        System.out.println("Score: " + (score * 100 / totalQuestions) + "%");
        
        scanner.close();
    }
}
