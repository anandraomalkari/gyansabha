#include <stdio.h>
int input();
int output(float);
int main()
{
    float result;
    char v;
    int num, nums, x, a, b, c, l, w, be, h, s, d, r,k, circle, square, rectangle, parallelogram, sphere, cylinder, cuboid, cube;
    clrscr();
    printf("\n\n");
    printf("\n--------------------------------------------------------\n");
    printf("\t--Mensuration System Project--\n");
    printf("\n--------------------------------------------------------\n");
    printf("\nMensuration System project provide you to calculate the measurement of\ngeomatrical figures and their paramenter.\n");
    printf("\nSelect any geomatrical figure from following :\n");
    printf("\n\n");
    printf("1. Circle\n");
    printf("2. Square\n");
    printf("3. Rectangle\n");
    printf("4. Parallelogram\n");
    printf("5. Sphere\n");
    printf("6. Cylinder\n");
    printf("7. Cuboid\n");
    printf("8. Cube\n");
    printf("9.To Exit\n");
    printf("\n");
    printf("Enter your choice:");
    scanf("%d", &x);
    switch (x){
    case 1:
    {
    printf("====================================================\n");
    printf("\n\n");
    printf("Circle Calculation\n");
    printf("*********************");
    printf("\n1.Enter the Area of Circle:\n\n2.Enter the Perimter of circle:\n\n3.Exit\n\n");
    printf("Enter Your Choise: ");

	circle = input();
	    switch (circle)
	    {
	      case 1:
			printf("*********************\n");
			printf("\nArea Of Circle Calculation\n");
			printf("----------------\n");
			printf("Enter radius: ");
			num = input();
			result = 3.14 * num * num;
			printf("\n\n");
			printf("Area of circle= ");
			output(result);
			break;

	      case 2:
			printf("**********************\n");
			printf("\nPerimeter Of Circle Calculation\n");
			printf("------------------\n");
			printf("Enter radius:");
			nums = input();
			result = 2 * 3.14 * nums;
			printf("\n\n");
			printf("Perimeter of circle = ");
			output(result);
			break;

	    }
	    break;

    }
    case 2:
    {
    printf("----------------------------------------------------\n");
    printf("Square Calculation");
    printf("\n1.Enter the Area of Square\n2.Enter the Perimter of Square:\n3. Exit");
    printf("Enter Your Choise: \n");
	square = input();
	    switch (square)
	    {
	      case 1:
			printf("*********************\n");
			printf("\nArea of Square Calculation\n ");
			printf("--------------------\n");
			printf("Enter Side in CM: ");
			a = input();
			result = a * a;
			printf("\n\n");
			printf("Area of Square= ");
			output(result);
			break;

	      case 2:
			printf("*********************\n");
			printf("\nPerimeter of Square Calculation\n");
			printf("---------------------\n");
			printf("Enter Side in CM: ");
			b = input();
			result = 4 * c;
			printf("\n\n");
			printf("Perimeter of Square = ");
			output(result);
			break;
	    }
      break;
    }
    case 3:
    {
    printf("----------------------------------------------------\n");
    printf("Rectangle Calculation");
    printf("\n1.Enter the Area of Rectangle\n2.Enter the Perimter of Rectangle\n3.Exit\n");
    printf("Enter Your Choise: \n");
	rectangle = input();
	    switch (rectangle)
	    {
	      case 1:
			printf("*****************\n");
			printf("Area of Rectangle Calculation\n");
			printf("----------------\n");
			printf("Length= ");
			l = input();
			printf("Width= ");
			b = input();
			result = l * b;
			printf("\n\n");
			printf("Area Of Rectangle: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Perimeter of Rectangle Calculation\n");
			printf("----------------\n");
			printf("Length= ");
			l = input();
			printf("Width= ");
			b = input();
			result = 2 * (l + b);
			printf("\n\n");
			printf("Perimeter Of Rectangle: ");
			output(result);
			break;

	    }
      break;
    }
    case 4:
    {
    printf("----------------------------------------------------\n");
    printf("Parallelogram Calculation");
    printf("\n1.Enter the Area of Parallelogram\n2.Enter the Perimter of Parallelogram\n3.Exit\n");
    printf("Enter Your Choise: \n");

    parallelogram = input();
	switch (parallelogram)
	    {
	      case 1:
			printf("*****************\n");
			printf("Area of Parallelogram Calculation\n");
			printf("----------------\n");
			printf("Base= ");
			be = input();
			printf("Height= ");
			h = input();
			result = be * h;
			printf("\n\n");
			printf("Area Of Parallelogram: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Perimeter of Parallelogram Calculation\n");
			printf("----------------\n");
			printf("Base= ");
			be = input();
			printf("Side= ");
			s = input();
			result = 2 * (be + s);
			printf("\n\n");
			printf("Perimeter Of Parallelogram: ");
			output(result);
			break;

	    }

      break;
    }
    case 5:
    {
    printf("----------------------------------------------------\n");
    printf("Sphere Calculation");
    printf("\n1.Find the Volume of Sphere\n2.Find the Curved Surface Area\n3.Exit");
    printf("Enter Your Choise: \n");
	sphere = input();
	    switch (sphere)
	    {
	      case 1:
			printf("*****************\n");
			printf("Volume of Sphere Calculation\n");
			printf("----------------\n");
			printf("Enter Radius = ");
			r = input();
			result = 1.33 * 3.14 * r * r * r;
			printf("\n\n");
			printf("Volume Of Sphere: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Curved Surface Area Calculation\n");
			printf("----------------\n");
			printf("Surface area of sphere= ");
			r = input();
			result = 4 * 3.14 * r * r;
			printf("\n\n");
			printf("Curved Surface Area is: ");
			output(result);
			break;

	    }
      break;

    }
    case 6:
    {
    printf("----------------------------------------------------\n");
    printf("Cylinder Calculation");
    printf("\n1.Find the Volume of Cylinder\n2.Find the Curved Surface Area\n3.Find Total Surface Area\n4.Exit\n");
    printf("Enter Your Choise: \n");
	cylinder = input();
	    switch (cylinder)
	    {
	      case 1:
			printf("*****************\n");
			printf("Volume of Cylinder Calculation\n");
			printf("----------------\n");
			printf("Enter Radius =");
			r = input();
			printf("Enter height = ");
			h = input();
			result = 3.14 * r * r * h;
			printf("\n\n");
			printf("Volume Of Cylinder: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Curved SUrface Area Calculation\n");
			printf("----------------\n");
			printf("Enter Radius = ");
			r = input();
			printf("Enter Height = ");
			h = input();
			result = 2 * 3.14 * r * h;
			printf("\n\n");
			printf("Curved Surface Area is: ");
			output(result);
			break;

	      case 3:
			printf("*****************\n");
			printf("Total Surface Area Calculation\n");
			printf("----------------\n");
			printf("Enter Radius =");
			r = input();
			printf("Enter Height =");
			h = input();
			result = (2 * 3.14 * r * h) + (2 * 3.14 * r * r);
			printf("\n\n");
			printf("Total Surfcae Area is:");
			output(result);
			break;
	    }

      break;

    }
    case 7:
    {
    printf("----------------------------------------------------\n");
    printf("Cuboid Calculation");
    printf("\n1.Find the Volume of Cuboid\n2.Find the Curved Surface Area of Cuboid\n3.Find Total Surface Area of Cuboid\n4.Exit\n");
    printf("Enter Your Choise: \n");
	cuboid = input();
	    switch (cuboid)
	    {
	      case 1:
			printf("*****************\n");
			printf("Volume of Cuboid Calculation\n");
			printf("----------------\n");
			printf("Enter length =");
			l = input();
			printf("Enter width = ");
			w = input();
			printf("Enter Height =");
			h = input();
			result = l * w * h;
			printf("\n\n");
			printf("Volume Of Cuboid: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Lateral Surface Area Calculation\n");
			printf("----------------\n");
			printf("Enter Height = ");
			h = input();
			printf("Enter Length = ");
			l = input();
			printf("Enter Width = ");
			w = input();
			result = 2 * h * (l + w);
			printf("\n\n");
			printf("Lateral Surface Area is: ");
			output(result);
			break;

	      case 3:
			printf("*****************\n");
			printf("Total Surface Area Calculation\n");
			printf("----------------\n");
			printf("Enter Height = ");
			h = input();
			printf("Enter Length = ");
			l = input();
			printf("Enter Width = ");
			w = input();
			result = 2 * ((l*w) + (w*h) + (h*l));
			printf("\n\n");
			printf("Total Surface Area is: ");
			output(result);
			break;
	    }

      break;
    }
    case 8:
    {
    printf("----------------------------------------------------\n");
    printf("Cube Calculation");
    printf("\n1.Find the Volume of Cube\n2.Find the Curved Surface Area of Cube\n3.Find Total Surface Area of Cube\n4.Exit\n");
    printf("Enter Your Choise: \n");
	cube = input();
	    switch (cube)
	    {
	      case 1:
			printf("*****************\n");
			printf("Volume of Cube Calculation\n");
			printf("----------------\n");
			printf("Enter Area = ");
			a = input();
			result = a * a * a;
			printf("\n\n");
			printf("Volume Of Cube: ");
			output(result);
			break;

	      case 2:
			printf("*****************\n");
			printf("Lateral Surface Area Calculation\n");
			printf("----------------\n");
			printf("Enter Area = ");
			a = input();
			result = 4 * a * a;
			printf("Lateral Surface Area is: ");
			printf("\n\n");
			output(result);
			break;

	      case 3:
			printf("*****************\n");
			printf("Total Surace Area Calculation\n");
			printf("----------------\n");
			printf("Enter Area = ");
			h = input();
			result = 6 * a * a;
			printf("\n\n");
			printf("Total Surface Area is: ");
			output(result);
			break;
	    }

    break;

    }
    default:
       printf("\tWrong Input\n");
       break;
    }
    return 0;
}
int input()
{
    int number;
    scanf("%d", &number);
    return (number);
}

int output(float number)
  {
    printf("%.2f", number);
    printf("\n\n");
    printf("================\n");
    printf("Thank You For the Calculation");
    getch();
  }